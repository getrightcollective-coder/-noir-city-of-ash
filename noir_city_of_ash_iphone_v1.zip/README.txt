NOIR: City of Ash — iPhone V1
Open index.html in a mobile-capable web host to play.
This is an original prototype; no copyrighted game assets are included.
For a true App Store build, later package the game with an iOS-capable development environment and Apple signing.
